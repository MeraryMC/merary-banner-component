//placeholder for the nav bar
//implementation stretch goal
import React from 'react';

var Nav = (props) => (
  <div className="mer_nav">
  </div>
)

export default Nav;